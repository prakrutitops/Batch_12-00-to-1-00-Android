package com.manddprojectconsulant.medisplayer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.manddprojectconsulant.medisplayer.Adapter.SongListAdapter;
import com.manddprojectconsulant.medisplayer.Model.SongsModel;
import com.manddprojectconsulant.medisplayer.PublicApi.Public_Api;
import com.manddprojectconsulant.medisplayer.databinding.ActivityMainBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding mainBinding;
    List<SongsModel> list=new ArrayList<>();
    SongsModel songsModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainBinding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(mainBinding.getRoot());

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        mainBinding.mediaRecycler.setLayoutManager(layoutManager);


        StringRequest stringRequest = new StringRequest(Request.Method.POST, Public_Api.Songs_List, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {


                JSONArray array = null;
                try {
                    array = new JSONArray(response);
                    for (int i = 0; i < array.length(); i++) {

                        JSONObject object = array.getJSONObject(i);
                        songsModel=new SongsModel();
                        songsModel.setId(object.getInt("id"));
                        songsModel.setName(object.getString("name"));
                        songsModel.setUrl(object.getString("url"));
                        songsModel.setArtist_name(object.getString("artist_name"));

                        list.add(songsModel);

                        Log.d("TAG","onResponse"+response);





                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

                SongListAdapter songListAdapter=new SongListAdapter(list,MainActivity.this,songsModel);
                mainBinding.mediaRecycler.setAdapter(songListAdapter);



            }



    },new Response.ErrorListener()

    {
        @Override
        public void onErrorResponse (VolleyError error){

        Toast.makeText(MainActivity.this, "Fault in Internet" + error.getMessage(), Toast.LENGTH_SHORT).show();

    }
    });


    RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
        queue.add(stringRequest);


}
}