package com.manddprojectconsulant.medisplayer.PublicApi;

public class Public_Api {

    public static final String Songs_List="https://medisplayer.000webhostapp.com/Songs%20Api/songsview.php";


}
