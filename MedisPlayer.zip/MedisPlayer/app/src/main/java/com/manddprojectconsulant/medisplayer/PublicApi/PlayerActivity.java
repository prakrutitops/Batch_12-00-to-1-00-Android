package com.manddprojectconsulant.medisplayer.PublicApi;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.manddprojectconsulant.medisplayer.Adapter.SongListAdapter;
import com.manddprojectconsulant.medisplayer.Model.SongsModel;
import com.manddprojectconsulant.medisplayer.R;
import com.manddprojectconsulant.medisplayer.databinding.ActivityPlayerBinding;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PlayerActivity extends AppCompatActivity implements MediaPlayer.OnPreparedListener {

    ActivityPlayerBinding playerBinding;
    String name, artist_name, url;
    int position;
    private MediaPlayer mediaPlayer;
    List<SongsModel> list = new ArrayList<>();
    String songartist_name;
   String model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        playerBinding = ActivityPlayerBinding.inflate(getLayoutInflater());
        setContentView(playerBinding.getRoot());

        name = getIntent().getExtras().getString("name");
        artist_name = getIntent().getExtras().getString("artist_name");
        url = getIntent().getExtras().getString("url");
        position = getIntent().getExtras().getInt("position");

        songartist_name = name + " (" + artist_name + ") ";

        playerBinding.nameText.setText(songartist_name);
        playerBinding.nameText.setSelected(true);

        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
        } else {
            mediaPlayer = new MediaPlayer();
            try {
                mediaPlayer.setDataSource(url);
                mediaPlayer.prepareAsync();
                mediaPlayer.setOnPreparedListener(this);
                playerBinding.playImageview.setImageResource(R.drawable.ic_pause);


            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        playerBinding.playImageview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (mediaPlayer.isPlaying()) {
                    playerBinding.playImageview.setImageResource(R.drawable.ic_play_button);
                    mediaPlayer.pause();
                } else {
                    playerBinding.playImageview.setImageResource(R.drawable.ic_pause);
                    mediaPlayer.start();

                }


            }
        });

        playerBinding.previousImageview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mediaPlayer.stop();
                mediaPlayer.release();
                position = ((position-1)<0)?(list.size()-1):(position-1);

                Uri uri = Uri.parse(list.get(position).toString());
                mediaPlayer = MediaPlayer.create(PlayerActivity.this, uri);

                name = list.get(position).getName().toString();
                artist_name = list.get(position).getArtist_name().toString();

                songartist_name = name + " (" + artist_name + ") ";

                playerBinding.nameText.setText(songartist_name);


                mediaPlayer.start();



            }
        });


        playerBinding.nextImageview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                mediaPlayer.stop();
                mediaPlayer.release();
                position = ((position + 1) % list.size());

                Uri uri = Uri.parse(list.get(position).toString());
                mediaPlayer = MediaPlayer.create(PlayerActivity.this, uri);

                name = list.get(position).getName().toString();
                artist_name = list.get(position).getArtist_name().toString();

                songartist_name = name + " (" + artist_name + ") ";

                playerBinding.nameText.setText(songartist_name);


                mediaPlayer.start();




            }
        });


    }


    @Override
    public void onPrepared(MediaPlayer mediaPlayer) {

        mediaPlayer.start();
    }
}