package com.manddprojectconsulant.medisplayer.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.manddprojectconsulant.medisplayer.MainActivity;
import com.manddprojectconsulant.medisplayer.Model.SongsModel;
import com.manddprojectconsulant.medisplayer.PublicApi.PlayerActivity;
import com.manddprojectconsulant.medisplayer.R;

import java.util.List;

public class SongListAdapter extends RecyclerView.Adapter<SongListAdapter.MyHolder> {

    List<SongsModel> list;
    Context context;
    SongsModel model;

    public SongListAdapter(List<SongsModel> list, MainActivity context,SongsModel model) {

        this.list=list;
        this.context=context;
        this.model=model;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater=LayoutInflater.from(context);
        View view=layoutInflater.inflate(R.layout.designforsonglist,parent,false);


        return new MyHolder(view);
    }



    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position) {

        holder.songsname_textview.setText(list.get(position).getName());
        holder.artistname_textview.setHint(list.get(position).getArtist_name());
        holder.music_imageview.setImageResource(R.drawable.ic_music);

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



              //  Toast.makeText(context, "Postion"+list.add(model), Toast.LENGTH_SHORT).show();

              //  int id=list.get(position);
                Intent player=new Intent(context, PlayerActivity.class);
                player.putExtra("position", holder.getAdapterPosition());
                player.putExtra("list",list.add(model));
                player.putExtra("name",list.get(position).getName());
                player.putExtra("artist_name",list.get(position).getArtist_name());
                player.putExtra("url",list.get(position).getUrl());
                context.startActivity(player);

            }
        });







    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        ImageView music_imageview;
        TextView songsname_textview,artistname_textview;
        CardView cardView;

        public MyHolder(@NonNull View itemView) {
            super(itemView);


            songsname_textview=itemView.findViewById(R.id.songsname_textview);
            artistname_textview=itemView.findViewById(R.id.artistname_textview);
            music_imageview=itemView.findViewById(R.id.music_imageview);
            cardView=itemView.findViewById(R.id.cardview);


        }
    }
}
