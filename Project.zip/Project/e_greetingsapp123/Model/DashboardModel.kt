package com.example.e_greetingsapp123.Model

class DashboardModel
{
    var c_id=""
    var c_name=""
    var c_image=""

}