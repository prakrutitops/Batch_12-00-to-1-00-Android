package com.example.e_greetingsapp123.Model

class Category_Model
{
    var id=0
    var image=""
}