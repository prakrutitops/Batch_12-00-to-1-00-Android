package tops.tech.batchproject_morning.Activity

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.razorpay.Checkout
import com.razorpay.PaymentResultListener
import com.squareup.picasso.Picasso
import org.json.JSONException
import org.json.JSONObject
import tops.tech.batchproject_morning.R
import tops.tech.batchproject_morning.databinding.ActivityLoginBinding
import tops.tech.batchproject_morning.databinding.ActivityPaymentBinding

class PaymentActivity : AppCompatActivity(), PaymentResultListener
{
    private lateinit var binding: ActivityPaymentBinding
    lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPaymentBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        sharedPreferences = getSharedPreferences("user_session", Context.MODE_PRIVATE)
        var i = intent
        var id = i.getStringExtra("id")
        var name = i.getStringExtra(("name"))
        var des = i.getStringExtra(("description"))
        var price = i.getStringExtra(("price"))
        var image =  i.getStringExtra(("image"))

        binding.giftName.text = name
        binding.giftDesc.text = des
        binding.giftPrice.text = price
        Picasso.get().load(image).into(binding.imageView)


        //form address
        //btn


        binding.makePaymentBtn.setOnClickListener {

            val pPrice = Integer.parseInt(price)*100
            val checkout = Checkout()
            checkout.setKeyID("")
            val obj = JSONObject()
            try {
                obj.put("name", name)
                obj.put("description", "Test Payment")
                obj.put("theme.color", "")
                obj.put("currency", "INR")
                obj.put("amount", pPrice)
                obj.put("prefill.contact", sharedPreferences.getString("mob", ""))
                obj.put("prefill.email", "jchirag2000@gmail.com")
                checkout.open(this, obj)
            } catch (e: JSONException) {
                e.printStackTrace()
            }

        }


    }

    override fun onPaymentSuccess(p0: String?) {



        //form data fill up
        //code add data in order table
        //Thread.sleep(3000)
        Toast.makeText(this, "Payment Success $p0", Toast.LENGTH_SHORT).show()
    }

    override fun onPaymentError(p0: Int, p1: String?) {

        Toast.makeText(this, "Payment Failed $p0 : $p1", Toast.LENGTH_SHORT).show()
    }
}