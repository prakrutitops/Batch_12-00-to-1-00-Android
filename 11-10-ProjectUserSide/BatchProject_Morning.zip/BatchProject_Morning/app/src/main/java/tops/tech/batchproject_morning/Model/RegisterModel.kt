package tops.tech.batchproject_morning

class RegisterModel
{
    var firstname=""
    var lastname=""
    var gender=""
    var email=""
    var phone=""
    var password=""

}