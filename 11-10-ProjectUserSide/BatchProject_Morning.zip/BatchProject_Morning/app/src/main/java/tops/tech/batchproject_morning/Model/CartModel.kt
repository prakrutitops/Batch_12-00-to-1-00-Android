package tops.tech.batchproject_morning.Model

class CartModel
{
    val id = 0
    val image = ""
    val gift_name = ""
    val gift_price = ""
    val gift_description = ""
}