<?php
    
    include('project_db_connect.php');
    
    $mob = $_REQUEST["mobile"];
    
    
    $sql="select * from wishlist where mobile ='$mob'";
    
    $r=mysqli_query($con,$sql);
    $response=array();
    
    while($row=mysqli_fetch_array($r))
    {
        $value["id"]=$row["id"];
        $value["gift_name"]=$row["gift_name"];
        $value["gift_description"]=$row["gift_description"];
         $value["gift_price"]=$row["gift_price"];
          $value["image"]=$row["image"];
           $value["mobile"]=$row["mobile"];
        array_push($response, $value);
    }
    echo json_encode($response);
    mysqli_close($con);

?>