<?php

    include('project_db_connect.php');
    
    $gift_name = $_POST["gift_name"];
    $gift_description = $_POST["gift_description"];
    $gift_price = $_POST["gift_price"];
    $image = $_POST["image"];
    $mob = $_POST["mobile"];
    
    if($gift_name == "" && $gift_description == "" && $gift_price == "" && $image == "" && $mob=="")
    {
        echo '0';
    }
    else
    {
        $sql = "insert into wishlist (gift_name, gift_description, gift_price, image, mobile) values ('$gift_name', '$gift_description',  '$gift_price', '$image','$mob')";
        $ex = mysqli_query($con, $sql);
        mysqli_close($con);
    }

?>