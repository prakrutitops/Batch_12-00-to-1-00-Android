<?php

    include('project_db_connect.php');
    
    $pid=$_POST["id"];
    
    $sql = "Delete from cart where id = '$pid'";
    //echo $sql;
    if(mysqli_query($con, $sql))
    {
        echo 'Deleted successfully.';
    }
    else
    {
        echo 'Something went wrong.';
    }

?>