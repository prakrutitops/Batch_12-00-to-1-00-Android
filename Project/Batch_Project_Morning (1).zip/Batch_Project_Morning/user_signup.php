<?php

    include('project_db_connect.php');
    
    $fname = $_POST["user_first_name"];
    $lname = $_POST["user_last_name"];
    $phone = $_POST["user_phone"];
    $gender = $_POST["user_gender"];
    $email = $_POST["user_email"];
    $pass = $_POST["user_password"];
    
    if($fname == "" && $lname == "" && $phone == "" && $gender == ""  && $email == "" && $pass == "")
    {
        echo '0';
    }
    else
    {
        $sql = "insert into project_users (user_first_name, user_last_name, user_phone, user_gender, user_email, user_password) values ('$fname', '$lname',  '$phone', '$gender', '$email', '$pass')";
        $ex = mysqli_query($con, $sql);
        mysqli_close($con);
    }

?>