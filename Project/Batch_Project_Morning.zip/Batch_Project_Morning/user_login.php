<?php

    include('project_db_connect.php');
    
    $phone = $_REQUEST["user_phone"];
    $pass = $_REQUEST["user_password"];
    
    $sql = "select * from project_users where user_phone = '$phone' and user_password = '$pass'";
    
    $ex = mysqli_query($con, $sql);
    
    $no = mysqli_num_rows ($ex);
    
    //echo $no;
    
    if($no>0)
    {
        $fet = mysqli_fetch_object($ex);
        echo json_encode(['code' => 200]);
    }
    else
    {
        echo '0';
    }
?>